package com.noobstack.jewellery;

public interface IMonthlyLeave {
    String getEmp_id();
    String getFname();
    String getlName();
    Integer getSum();
}
